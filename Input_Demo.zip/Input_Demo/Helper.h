#pragma once
#ifndef HELPER_H
#define HELPER_H

void SaveSettings();
void LoadSettings();

extern wchar_t playerAName[50];
extern wchar_t playerBName[50];
extern int countdown;
extern int currentJury;

#endif // HELPER_H
